					<div class="lateral"><!--widget-->
						<div class="zon_pub">
							<div id="zon_pub_J">
								<?php include("zon_pub/zon_J.html");?>
							</div>
						</div>

						<div class="zon_pub">
							<div id="zon_pub_K">
								<?php include("zon_pub/zon_K.html");?>
							</div>
						</div>

						<div class="zon_pub">
							<div id="zon_pub_L">
								<?php include("zon_pub/zon_L.html");?>
							</div>
						</div>
						<div class="side">
							<?php if (!dynamic_sidebar($nom_wid));?>
						</div>
					</div><!-- fin widget-->
					<div class="limpiar"></div>
					<div class="espacio05"></div>
					<div class="sep"></div>
					<div class="espacio05"></div>
